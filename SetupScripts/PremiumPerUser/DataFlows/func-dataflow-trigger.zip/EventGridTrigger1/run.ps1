param($eventGridEvent, $TriggerMetadata)
# Assign file path to check
# Make sure to pass hashtables to Out-String so they're logged correctly
$relFilePath = $eventGridEvent.subject | Out-String
$eventType = $eventGridEvent.eventType | Out-String

# Delete with delete
# Only work with snapshot files that are created
if($relFilePath -like "*model.json@snapshot*")
{
    # Get URL of file
    $blobUrl = $eventGridEvent.data.url | Out-String

    Write-Host "Downloading updated file: $($blobUrl)"

    # Connect to Azure using Managed Identity 
    $connectionStatus = Connect-AzAccount -Identity
    # Get the Storage Context
    $ctx = New-AzStorageContext -StorageAccountName $ENV:StorageAccountName -UseConnectedAccount

    if($connectionStatus)
    {
        # Set substring to parse url to fit Powershell commands
        $powerBIStr = "/powerbi/"
        $ind = $blobUrl.IndexOf($powerBIStr)

        # Make sure no issue
        if($ind -eq -1)
        {
            throw "Error: '$($powerBIStr)' string not found"
        }
        else
        {
            $relUrl = $blobUrl.SubString($ind + $powerBIStr.Length).Trim()
            # Retrieve file from Blob
            Get-AzDataLakeGen2ItemContent -Context $ctx -FileSystem "powerbi" -Destination "." -Path $relUrl -Force

            # With the file download let's push to Git
            
            # Split by forward slash to get folder path
            $splitUrl = $relUrl.Split("/") 
            # Set File Name
            $fileName = $splitUrl | Select -Last 1
            # Double check we setup the push JSON
            if($splitUrl.Count -lt 2)
            {
                throw "Invalid URL to parse: $($relUrl)"
            }# end if

            $splitUrl = $splitUrl | Select -First 2
            $folderPath = $splitUrl -join ("/")               
            $pathForModelContent = "DataFlows/$($folderPath)/model.json"
            # Replace colon with %3A
            $escapeRelUrl = $relUrl.Replace(":","%3A")
            Get-Content -Path "./$($escapeRelUrl)"
            $modelContentJSON = Get-Content -Path "./$($escapeRelUrl)"

            # Retrieve environment variables
            $organizationName = $ENV:OrganizationName
            $aDOProjectName = $ENV:AzureDevOpsProjectName
            $aDOPAT = $ENV:AzureDevOpsPAT
            $aDORepoId = $ENV:AzureDevOpsRepositoryId

            # Setup URLs to issue to Azure DevOps
            $uriOrga = "https://dev.azure.com/$($organizationName)/" 
            $aDOAuthenicationHeader = @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($aDOPAT)")) }
            $uriPush = "$($uriOrga)$($aDOProjectName)/_apis/git/repositories/$($aDORepoId)/pushes?api-version=5.1"
            $uriRef = "$($uriOrga)$($aDOProjectName)/_apis/git/repositories/$($aDORepoId)/refs?api-version=5.1"
            $branchName = $ENV:AzureDevOpsBranch
            
            #Template for push
            $addTemplate = @{
            "refUpdates" = @(
                @{
                "name" = "refs/heads/part20"
                "oldObjectId" = "8b67126d2500e28c771f82c9ddc292679978197c"
                }
            )
            "commits" = @(
                @{
                    "comment" = "Automated update of model json file"
                    "changes" = @(
                        @{
                            "changeType" = "add"
                            "item" = @{
                                "path" = "folder1/task3.md"
                            }
                            "newContent" = @{
                                "content" = "# Tasks\n\n* Item 1\n* Item A"
                                "contentType" = "rawtext"
                            }
                        }
                    )
                }
            )}

            # Get Ref to get oldObjectId
            $refResult = Invoke-RestMethod -Uri $uriRef -Method Get -Headers $aDOAuthenicationHeader -Verbose

            # Get Refs for the appropriate branch
            $branchRef = $refResult.value | Where-Object { $_.name -eq $branchName}
            # Set variables for tracking requests
            $jSONBody = ""
            # Use to flag to store if the file is being added or edited
            $isAdd = $FALSE
           
            # Check for Branch ref
            if($branchRef -eq $null)
            {
                throw "Unable to get referenced Id for repository: $($aDORepoId) and branch: $($branchName)."
            }
            else #Add or Update
            {
                $isAdd = $TRUE
                # Use template to create body for request
                $addJSON = $addTemplate
                # Assign reference Id and name to template JSON    
                $addJSON.refUpdates[0].oldObjectId = $branchRef.objectId
                $addJSON.refUpdates[0].name = $branchName
                # Update template with the model.json content with appropriate path and content
                $addJSON.commits[0].comment = "Update model with new version: $($fileName)"
                $addJSON.commits[0].changes[0].item.path = $pathForModelContent
                $addJSON.commits[0].changes[0].newContent.content = "$($modelContentJSON)"
                $jSONBody = $addJSON | ConvertTo-Json -Depth 5
            }#end if
            
            # Push to appropriate repo and branch with add
            Try
            {
                Invoke-RestMethod -Uri $uriPush -Method Post -Headers $aDOAuthenicationHeader -Body $jSONBody -ContentType "application/json"
            }Catch [System.Exception]{
                $errObj = ($_).ToString() | ConvertFrom-Json
            
                #Switch to edit instead of add
                if($errObj.message -like "*add operation already exists*")
                {
                    $isAdd = $FALSE
                }
                else #not the error we were looking for
                {
                    throw $errObj
                }
            }#End Try

            if($isAdd -eq $FALSE) # Issue edit request instead
            {
                $editJSON = $addJSON
                $editJSON.commits[0].changes[0].changeType = "edit"
                $jSONBody = $editJSON | ConvertTo-Json -Depth 5
                # Issue Edit Request
                Invoke-RestMethod -Uri $uriPush -Method Post -Headers $aDOAuthenicationHeader -Body $jSONBody -ContentType "application/json"

                # Delete file to clean up Azure Functions
                Remove-Item -Path "./$($escapeRelUrl)" -Force
            }# end if Is Add check
        }# endif index check
    }# end connection status check
}# end relFilePath check